import TileGallery from "@/components/TileGallery";

export const metadata = {
  title: "16x16 Tiles | Sepione Ceramic",
  description: "Browse our premium 16x16 tiles collection.",
};

export default function Tiles16x16Page() {
  return (
    <main>
      <TileGallery title="16x16 Tiles" size="16x16" />
    </main>
  );
}
