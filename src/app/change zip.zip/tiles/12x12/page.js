import TileGallery from "@/components/TileGallery";

export const metadata = {
  title: "12x12 Tiles | Sepione Ceramic",
  description: "Browse our premium 12x12 tiles collection.",
};

export default function Tiles12x12Page() {
  return (
    <main>
      <TileGallery title="12x12 Tiles" size="12x12" />
    </main>
  );
}
