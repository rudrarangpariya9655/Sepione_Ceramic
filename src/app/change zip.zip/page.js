"use client";
import Link from "next/link";
import { useState, useEffect } from "react";
import { supabaseClient } from '@/lib/supabase/client';

export default function Home() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isShopDropdownOpen, setIsShopDropdownOpen] = useState(false);
  
  const [heroTile, setHeroTile] = useState(null);
  const [tiles12x12, setTiles12x12] = useState([]);
  const [tiles16x16, setTiles16x16] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchHomepageData() {
      try {
        // Fetch hero tile (newest global)
        const { data: heroData } = await supabaseClient
          .from('tile_images')
          .select('cloudinary_secure_url')
          .eq('upload_status', 'SUCCESS')
          .order('created_at', { ascending: false })
          .limit(1);
          
        if (heroData && heroData.length > 0) {
          setHeroTile(heroData[0].cloudinary_secure_url);
        }

        // Fetch top 3 for 12x12
        const { data: data12x12 } = await supabaseClient
          .from('tile_images')
          .select('*')
          .eq('upload_status', 'SUCCESS')
          .eq('size', '12x12')
          .order('created_at', { ascending: false })
          .limit(3);
        if (data12x12) setTiles12x12(data12x12);

        // Fetch top 3 for 16x16
        const { data: data16x16 } = await supabaseClient
          .from('tile_images')
          .select('*')
          .eq('upload_status', 'SUCCESS')
          .eq('size', '16x16')
          .order('created_at', { ascending: false })
          .limit(3);
        if (data16x16) setTiles16x16(data16x16);
        
      } catch (e) {
        console.error("Failed to fetch homepage data", e);
      } finally {
        setIsLoading(false);
      }
    }
    fetchHomepageData();
  }, []);

  return (
    <>
      {/* Top Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-surface/80 dark:bg-surface/80 backdrop-blur-xl border-b border-white/10 shadow-2xl shadow-black/20">
        <div className="flex justify-between items-center px-margin-mobile md:px-margin-desktop py-6 w-full max-w-container-max mx-auto">
          <div className="font-headline-md text-headline-md font-bold text-primary tracking-tighter">
            Sepione Ceramic
          </div>
          
          {/* Desktop Links */}
          <div className="hidden md:flex space-x-gutter items-center font-body-md text-body-md uppercase tracking-[0.2em]">
            <Link href="/" className="text-primary border-b border-primary pb-1 hover:opacity-80 transition-all duration-300">Home</Link>
            <Link href="/tiles/12x12" className="text-on-surface-variant hover:text-primary transition-colors duration-300 hover:opacity-80">12x12</Link>
            <Link href="/tiles/16x16" className="text-on-surface-variant hover:text-primary transition-colors duration-300 hover:opacity-80">16x16</Link>
            <a href="#contact" className="text-on-surface-variant hover:text-primary transition-colors duration-300 hover:opacity-80">Contact</a>
          </div>
          <div className="hidden md:flex items-center space-x-6 relative">
            <button 
              onClick={() => setIsShopDropdownOpen(!isShopDropdownOpen)}
              className="text-primary dark:text-primary-fixed-dim hover:opacity-80 transition-all duration-300 flex items-center gap-2 cursor-pointer"
            >
              <span className="font-body-md text-body-md uppercase tracking-[0.2em]">Shop Now</span>
              <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 transition-transform duration-300 ${isShopDropdownOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            
            {/* Dropdown Menu */}
            <div className={`absolute top-full right-0 mt-6 w-48 bg-surface-container-high border border-white/10 shadow-2xl rounded-xl overflow-hidden transition-all duration-300 flex flex-col origin-top-right ${isShopDropdownOpen ? 'opacity-100 scale-100 visible' : 'opacity-0 scale-95 invisible'}`}>
              <Link 
                href="/tiles/12x12" 
                className="px-6 py-4 text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors font-body-md uppercase tracking-widest text-sm border-b border-white/5"
                onClick={() => setIsShopDropdownOpen(false)}
              >
                12x12 Tiles
              </Link>
              <Link 
                href="/tiles/16x16" 
                className="px-6 py-4 text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors font-body-md uppercase tracking-widest text-sm"
                onClick={() => setIsShopDropdownOpen(false)}
              >
                16x16 Tiles
              </Link>
            </div>
          </div>
          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden text-primary"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle menu"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
              {isMobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5M3.75 17.25h16.5" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Menu Dropdown */}
        {isMobileMenuOpen && (
          <div className="md:hidden absolute top-full left-0 w-full bg-surface-container-high border-b border-white/10 shadow-2xl flex flex-col p-6 gap-6">
            <Link href="/" className="font-body-lg text-primary uppercase tracking-[0.2em]" onClick={() => setIsMobileMenuOpen(false)}>Home</Link>
            <Link href="/tiles/12x12" className="font-body-lg text-on-surface-variant uppercase tracking-[0.2em]" onClick={() => setIsMobileMenuOpen(false)}>12x12</Link>
            <Link href="/tiles/16x16" className="font-body-lg text-on-surface-variant uppercase tracking-[0.2em]" onClick={() => setIsMobileMenuOpen(false)}>16x16</Link>
            <a href="#contact" className="font-body-lg text-on-surface-variant uppercase tracking-[0.2em]" onClick={() => setIsMobileMenuOpen(false)}>Contact</a>
            <Link href="/tiles/12x12" className="font-body-lg text-primary uppercase tracking-[0.2em] mt-4" onClick={() => setIsMobileMenuOpen(false)}>Shop Now</Link>
          </div>
        )}
      </nav>

      <main className="pt-[140px] pb-section-gap px-6 md:px-margin-desktop max-w-container-max mx-auto space-y-section-gap overflow-x-hidden">
        
        {/* Hero Section */}
        <section className="grid grid-cols-12 gap-gutter items-center min-h-[716px]">
          <div className="col-span-12 md:col-span-7 z-10">
            <h1 className="font-display-xl text-6xl md:text-display-xl text-on-surface mb-8 relative leading-tight">
              <span className="block text-primary-container relative z-10 mix-blend-difference">Earth.</span>
              <span className="block pl-12 text-on-surface">Refined.</span>
            </h1>
            <p className="font-body-lg text-body-lg text-on-surface-variant max-w-xl mb-12 border-l-2 border-primary-container pl-6">
              Avant-garde ceramics crafted for spaces that demand presence. Where raw clay meets monumental scale.
            </p>
            <Link href="/tiles/12x12" className="bg-primary-container text-on-primary-container font-label-sm text-label-sm uppercase px-8 py-4 rounded-full hover:scale-105 transition-transform duration-300 flex items-center gap-2 w-max text-black no-underline">
              Explore Collections
              <span>→</span>
            </Link>
          </div>
          <div className="col-span-12 md:col-span-5 relative mt-12 md:mt-0">
            <div className="aspect-[4/5] rounded-[3rem] overflow-hidden ambient-shadow relative">
              <div 
                className="bg-cover bg-center w-full h-full absolute inset-0 transition-opacity duration-1000" 
                style={{ 
                  backgroundImage: `url('${heroTile || 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100%25" height="100%25"%3E%3Crect width="100%25" height="100%25" fill="%232d2a26"/%3E%3C/svg%3E'}')`,
                  opacity: isLoading ? 0 : 1
                }}
              ></div>
            </div>
            {/* Floating Element */}
            <div className="absolute -bottom-12 -left-12 bg-surface-container p-6 rounded-lg backdrop-blur-md border border-white/5 ambient-shadow w-64 hidden md:block">
              <div className="font-label-sm text-label-sm text-on-surface-variant uppercase mb-2">Featured Finish</div>
              <div className="font-headline-md text-headline-md text-primary-container">Oxidized Copper</div>
            </div>
          </div>
        </section>

        {/* 12x12 Collection (Asymmetric Bento) */}
        <section>
          <div className="flex items-end justify-between mb-16">
            <div>
              <span className="font-label-sm text-label-sm text-primary-container uppercase tracking-widest block mb-4">Standard Format</span>
              <h2 className="font-headline-lg text-4xl md:text-headline-lg text-on-surface">12x12 Collection</h2>
            </div>
            <Link href="/tiles/12x12" className="font-label-sm text-label-sm text-on-surface hover:text-primary-container transition-colors uppercase flex items-center gap-2 hidden md:flex no-underline">
              View All Standard <span>→</span>
            </Link>
          </div>
          <div className="grid grid-cols-12 gap-gutter">
            {/* Large Feature Tile */}
            {tiles12x12[0] && (
              <div className="col-span-12 md:col-span-8 group cursor-pointer relative">
                <Link href="/tiles/12x12" className="block no-underline">
                  <div className="aspect-[16/9] rounded-[2rem] overflow-hidden relative ambient-shadow mb-6">
                    <div 
                      className="bg-cover bg-center w-full h-full absolute inset-0 transition-transform duration-700 group-hover:scale-105" 
                      style={{ backgroundImage: `url('${tiles12x12[0].cloudinary_secure_url}')` }}
                    ></div>
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors duration-500"></div>
                    {/* Tag */}
                    <div className="absolute top-6 left-6 bg-[#525EA7] text-white font-label-sm text-label-sm px-4 py-2 rounded-full uppercase tracking-widest">Newest Arrival</div>
                  </div>
                  <h3 className="font-headline-md text-headline-md text-on-surface group-hover:text-primary-container transition-colors">{tiles12x12[0].filename}</h3>
                  <p className="font-body-md text-body-md text-on-surface-variant mt-2 uppercase text-xs tracking-widest">{tiles12x12[0].category}</p>
                </Link>
              </div>
            )}
            
            {/* Stacked Secondary Tiles */}
            <div className="col-span-12 md:col-span-4 flex flex-col gap-gutter">
              {tiles12x12.slice(1, 3).map((tile, i) => (
                <Link key={i} href="/tiles/12x12" className="group cursor-pointer flex-1 block no-underline">
                  <div className="h-48 rounded-[2rem] overflow-hidden relative ambient-shadow mb-4">
                    <div 
                      className="bg-cover bg-center w-full h-full absolute inset-0 transition-transform duration-700 group-hover:scale-105" 
                      style={{ backgroundImage: `url('${tile.cloudinary_secure_url}')` }}
                    ></div>
                  </div>
                  <h3 className="font-headline-md text-headline-md text-on-surface group-hover:text-primary-container transition-colors text-2xl">{tile.filename}</h3>
                </Link>
              ))}
              {!isLoading && tiles12x12.length === 0 && (
                <div className="text-on-surface-variant text-sm border border-outline-variant/30 rounded-2xl p-6 text-center">No tiles uploaded yet.</div>
              )}
            </div>
          </div>
        </section>

        {/* 16x16 Collection (Expansive Horizontal Flow) */}
        <section className="bg-surface-container-low -mx-6 md:-mx-margin-desktop px-6 md:px-margin-desktop py-section-gap">
          <div className="max-w-container-max mx-auto">
            <div className="text-center mb-20 max-w-2xl mx-auto">
              <span className="font-label-sm text-label-sm text-primary-container uppercase tracking-widest block mb-4">Monumental Scale</span>
              <h2 className="font-headline-lg text-4xl md:text-headline-lg text-on-surface mb-6">16x16 Collection</h2>
              <p className="font-body-lg text-body-lg text-on-surface-variant">Expansive surfaces designed to minimize grout lines and maximize visual impact. For spaces that require unbroken flow.</p>
            </div>
            <div className="flex gap-gutter overflow-x-auto pb-12 snap-x hide-scrollbar">
              {tiles16x16.map((tile, i) => (
                <Link key={i} href="/tiles/16x16" className="min-w-[80vw] md:min-w-[45vw] lg:min-w-[30vw] snap-center group cursor-pointer mt-0 md:mt-12 block no-underline">
                  <div className="aspect-square rounded-[3rem] overflow-hidden relative ambient-shadow mb-6">
                    <div 
                      className="bg-cover bg-center w-full h-full absolute inset-0 transition-transform duration-1000 group-hover:scale-105" 
                      style={{ backgroundImage: `url('${tile.cloudinary_secure_url}')` }}
                    ></div>
                  </div>
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-headline-md text-headline-md text-on-surface">{tile.filename}</h3>
                      <p className="font-body-md text-body-md text-on-surface-variant mt-1 uppercase text-xs tracking-widest">{tile.category}</p>
                    </div>
                    <span className="text-primary-container opacity-0 group-hover:opacity-100 transition-opacity -translate-x-4 group-hover:translate-x-0 duration-300">→</span>
                  </div>
                </Link>
              ))}
              {!isLoading && tiles16x16.length === 0 && (
                <div className="text-on-surface-variant text-sm border border-outline-variant/30 rounded-2xl p-6 w-full text-center">No tiles uploaded yet.</div>
              )}
            </div>
          </div>
        </section>

        {/* Studio Contact Section */}
        <section className="grid grid-cols-12 gap-gutter items-center border-t border-outline-variant/30 pt-20" id="contact">
          <div className="col-span-12 md:col-span-5">
            <h2 className="font-headline-lg text-4xl md:text-headline-lg text-on-surface mb-8">Visit the Factory</h2>
            <p className="font-body-lg text-body-lg text-on-surface-variant mb-12">Experience the scale and texture of our collections in person. Private viewings available by appointment.</p>
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <span className="text-primary-container mt-1 font-bold">📍</span>
                <div>
                  <div className="font-label-sm text-label-sm text-on-surface-variant uppercase mb-1">Location</div>
                  <div className="font-body-md text-body-md text-on-surface">Pawadiyare Canal,<br/>Morbi, Gujarat, India</div>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <span className="text-primary-container mt-1 font-bold">☏</span>
                <div>
                  <div className="font-label-sm text-label-sm text-on-surface-variant uppercase mb-1">Phone</div>
                  <div className="font-body-md text-body-md text-on-surface">+91 90999 50773<br/>+91 90999 50771</div>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <span className="text-primary-container mt-1 font-bold">✉</span>
                <div>
                  <div className="font-label-sm text-label-sm text-on-surface-variant uppercase mb-1">Email</div>
                  <div className="font-body-md text-body-md text-on-surface">sepion@gmail.com</div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-span-12 md:col-span-6 md:col-start-7 mt-12 md:mt-0">
            <div className="aspect-[4/3] rounded-[3rem] overflow-hidden ambient-shadow">
              <div 
                className="bg-cover bg-center w-full h-full" 
                style={{ backgroundImage: "url('https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&q=80&w=1000')" }}
              ></div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
