import { NextResponse } from 'next/server';
import { supabaseServer } from '@/lib/supabase/server';
import cloudinary from '@/lib/cloudinary';

export async function GET(request) {
  // A small endpoint to fetch distinct categories for a given size
  const { searchParams } = new URL(request.url);
  const size = searchParams.get('size');
  const secret = request.headers.get('Authorization');

  if (secret !== process.env.ADMIN_SECRET) {
    return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  }

  if (!size) {
    return NextResponse.json({ success: false, error: "Size is required" }, { status: 400 });
  }

  // Supabase doesn't have a distinct() method, so we fetch and filter in JS
  const { data, error } = await supabaseServer
    .from('tile_images')
    .select('category')
    .eq('size', size);

  if (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }

  const distinctCategories = [...new Set(data.map(d => d.category))];
  return NextResponse.json({ success: true, categories: distinctCategories });
}

export async function POST(request) {
  try {
    const formData = await request.formData();
    const secret = formData.get('secret');
    
    if (secret !== process.env.ADMIN_SECRET) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const size = formData.get('size');
    const category = formData.get('category');
    const filename = formData.get('filename'); // Custom filename provided by user
    const file = formData.get('file');

    if (!size || !category || !filename || !file) {
      return NextResponse.json({ success: false, error: "Missing required fields" }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const cloudinaryFolder = `sepione-ceramic/${size}/${category}`;

    // Upload to Cloudinary using upload_stream
    const uploadResult = await new Promise((resolve, reject) => {
      const uploadStream = cloudinary.uploader.upload_stream(
        {
          folder: cloudinaryFolder,
          public_id: filename,
          use_filename: true,
          unique_filename: false,
          overwrite: true
        },
        (error, result) => {
          if (error) reject(error);
          else resolve(result);
        }
      );
      uploadStream.end(buffer);
    });

    // The local_path is simulated here for uniqueness since these don't come from a local file tree.
    // We'll use the Cloudinary folder + filename as the unique local_path to match bulk tool logic.
    const local_path = `${size}/${category}/${filename}.${file.name.split('.').pop()}`;

    // Insert into Supabase
    const { error: upsertError } = await supabaseServer
      .from('tile_images')
      .upsert({
        size,
        category,
        folder_path: `${size}/${category}`,
        filename,
        local_path,
        cloudinary_public_id: uploadResult.public_id,
        cloudinary_secure_url: uploadResult.secure_url,
        image_width: uploadResult.width,
        image_height: uploadResult.height,
        upload_status: 'SUCCESS',
        error_message: null,
        updated_at: new Date().toISOString()
      }, { onConflict: 'local_path' });

    if (upsertError) {
      throw upsertError;
    }

    return NextResponse.json({ success: true, message: "Tile uploaded successfully.", url: uploadResult.secure_url });

  } catch (error) {
    let errStr = error.message || "Unknown error";
    if (error.cause) {
      const causeInfo = error.cause.message || error.cause.code || JSON.stringify(error.cause);
      errStr += ` (Cause: ${causeInfo})`;
    }
    console.error("Manual upload error:", errStr);
    return NextResponse.json({ success: false, error: errStr }, { status: 500 });
  }
}
