import { NextResponse } from 'next/server';

export async function POST(request) {
  try {
    const { secret } = await request.json();

    if (!process.env.ADMIN_SECRET) {
      return NextResponse.json({ success: false, error: "ADMIN_SECRET is not configured on the server." }, { status: 500 });
    }

    if (secret === process.env.ADMIN_SECRET) {
      return NextResponse.json({ success: true });
    } else {
      return NextResponse.json({ success: false, error: "Invalid secret password." }, { status: 401 });
    }
  } catch (error) {
    return NextResponse.json({ success: false, error: "Bad request." }, { status: 400 });
  }
}
