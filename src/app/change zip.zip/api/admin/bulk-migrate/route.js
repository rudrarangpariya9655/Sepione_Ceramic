import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { supabaseServer } from '@/lib/supabase/server';
import cloudinary from '@/lib/cloudinary';

// Global state to track migration progress in the local Next.js server
let migrationState = {
  isRunning: false,
  totalFiles: 0,
  uploadedCount: 0,
  skippedCount: 0,
  failedCount: 0,
  currentFile: null,
  failedFiles: [], // { file: string, reason: string }
  isComplete: false,
};

async function walkDirectory(dir, fileList = []) {
  try {
    const files = await fs.promises.readdir(dir, { withFileTypes: true });
    for (const file of files) {
      const fullPath = path.join(dir, file.name);
      if (file.isDirectory()) {
        await walkDirectory(fullPath, fileList);
      } else {
        // Only include images
        if (file.name.match(/\.(jpg|jpeg|png|webp|avif)$/i)) {
          fileList.push(fullPath);
        }
      }
    }
  } catch (err) {
    console.error(`Error walking directory ${dir}:`, err);
  }
  return fileList;
}

export async function GET(request) {
  return NextResponse.json(migrationState);
}

export async function POST(request) {
  try {
    const { secret } = await request.json();

    if (secret !== process.env.ADMIN_SECRET) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    if (migrationState.isRunning) {
      return NextResponse.json({ success: false, error: "Migration is already running." }, { status: 400 });
    }

    const basePath = process.env.TILES_LOCAL_PATH;
    if (!basePath || !fs.existsSync(basePath)) {
      return NextResponse.json({ success: false, error: "TILES_LOCAL_PATH is invalid or not configured." }, { status: 400 });
    }

    // Check Cloudinary connectivity before starting the batch
    try {
      await cloudinary.api.ping();
    } catch (pingErr) {
      let causeStr = "";
      if (pingErr.cause) {
        causeStr = pingErr.cause.message || pingErr.cause.code || JSON.stringify(pingErr.cause);
      }
      return NextResponse.json({ 
        success: false, 
        error: `Cloudinary connection failed: ${pingErr.message || "Unknown ping error"}${causeStr ? ` (Cause: ${causeStr})` : ''}` 
      }, { status: 502 });
    }

    // Start background task
    runMigration(basePath).catch(err => {
      console.error("Fatal migration error:", err);
      migrationState.isRunning = false;
      migrationState.isComplete = true;
    });

    return NextResponse.json({ success: true, message: "Migration started." });

  } catch (error) {
    return NextResponse.json({ success: false, error: "Bad request." }, { status: 400 });
  }
}

async function runMigration(basePath) {
  // Reset State
  migrationState = {
    isRunning: true,
    totalFiles: 0,
    uploadedCount: 0,
    skippedCount: 0,
    failedCount: 0,
    currentFile: "Scanning folders...",
    failedFiles: [],
    isComplete: false,
  };

  try {
    // using supabaseServer directly

    const sizes = ['12x12', '16x16'];
    let allFiles = [];

    for (const size of sizes) {
      const sizePath = path.join(basePath, size);
      if (fs.existsSync(sizePath)) {
        await walkDirectory(sizePath, allFiles);
      }
    }

    migrationState.totalFiles = allFiles.length;

    // Process sequentially to respect rate limits and DB connections
    for (const filePath of allFiles) {
      migrationState.currentFile = filePath;
      
      try {
        // Parse the file path relative to the basePath
        // Expected: D:\Projects\Sepions Ceramic\jpg\12x12\Rustic\rustic-beige-01.jpg
        const relativePath = path.relative(basePath, filePath);
        // Normalize slashes for Cloudinary folder paths
        const normalizedRel = relativePath.split(path.sep).join('/');
        const parts = normalizedRel.split('/');
        
        if (parts.length < 3) {
          throw new Error("File is not inside a size/category structure.");
        }

        const size = parts[0]; // e.g. 12x12
        const category = parts[1]; // e.g. rustic
        const folder_path = parts.slice(0, -1).join('/'); // Entire relative path minus filename
        const filenameWithExt = parts[parts.length - 1]; // Just the file name
        const filename = path.parse(filenameWithExt).name;
        
        // Check if already successfully uploaded
        const { data: checkData, error: checkError } = await supabaseServer
          .from('tile_images')
          .select('upload_status')
          .eq('local_path', relativePath)
          .single();
          
        if (checkData && checkData.upload_status === 'SUCCESS') {
          migrationState.skippedCount++;
          continue;
        }

        // Upload to Cloudinary
        // Folder structure: exactly mirroring local structure
        const cloudinaryFolder = `sepione-ceramic/${folder_path}`;
        
        const uploadResult = await cloudinary.uploader.upload(filePath, {
          folder: cloudinaryFolder,
          public_id: filename,
          use_filename: true,
          unique_filename: false,
          overwrite: true
        });

        // Insert or Update DB
        const { error: upsertError } = await supabaseServer
          .from('tile_images')
          .upsert({
            size,
            category,
            folder_path,
            filename,
            local_path: relativePath,
            cloudinary_public_id: uploadResult.public_id,
            cloudinary_secure_url: uploadResult.secure_url,
            image_width: uploadResult.width,
            image_height: uploadResult.height,
            upload_status: 'SUCCESS',
            error_message: null,
            updated_at: new Date().toISOString()
          }, { onConflict: 'local_path' });

        if (upsertError) throw upsertError;
          
        migrationState.uploadedCount++;
      } catch (fileErr) {
        let errStr = fileErr.message || "Unknown error";
        if (fileErr.cause) {
          const causeInfo = fileErr.cause.message || fileErr.cause.code || JSON.stringify(fileErr.cause);
          errStr += ` (Cause: ${causeInfo})`;
        }
        console.error("Failed to process file:", filePath, errStr);
        migrationState.failedCount++;
        migrationState.failedFiles.push({ file: filePath, reason: errStr });
        
        // Attempt to log failure in DB if we at least parsed the basic details
        try {
          const relativePath = path.relative(basePath, filePath);
          const normalizedRel = relativePath.split(path.sep).join('/');
          const parts = normalizedRel.split('/');
          if (parts.length >= 3) {
            const size = parts[0];
            const category = parts[1];
            const folder_path = parts.slice(0, -1).join('/');
            const filename = path.parse(parts[parts.length - 1]).name;
            
            await supabaseServer
              .from('tile_images')
              .upsert({
                size,
                category,
                folder_path,
                filename,
                local_path: relativePath,
                upload_status: 'FAILED',
                error_message: errStr.substring(0, 4000),
                updated_at: new Date().toISOString()
              }, { onConflict: 'local_path' });
          }
        } catch (dbFailErr) {
          // Ignore DB failure for error logging
        }
      }
    }

  } catch (globalErr) {
    console.error("Global migration error:", globalErr);
  } finally {
    migrationState.isRunning = false;
    migrationState.isComplete = true;
    migrationState.currentFile = "Finished.";
  }
}
