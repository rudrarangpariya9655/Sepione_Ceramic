import { NextResponse } from 'next/server';
import { supabaseClient } from '@/lib/supabase/client';

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const size = searchParams.get('size');
  const category = searchParams.get('category');
  const limit = searchParams.get('limit');
  
  let query = supabaseClient
    .from('tile_images')
    .select('*')
    .eq('upload_status', 'SUCCESS')
    .order('created_at', { ascending: false });
    
  if (size) query = query.eq('size', size);
  if (category) query = query.eq('category', category);
  if (limit) query = query.limit(parseInt(limit));
  
  const { data, error } = await query;
  
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  
  return NextResponse.json({ tiles: data });
}
